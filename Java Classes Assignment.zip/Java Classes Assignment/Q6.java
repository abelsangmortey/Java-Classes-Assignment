package com.testObject;

public class Q6 {

int roomno = 1209;
String roomtype = "Classroom";
int noOfacM = 2;

int rooml, roomw;


public int setData(int l, int w){
 int A = l*w;
 return A;
}
  public void DisplayData() {
  
  System.out.println("F" + roomno);
 
  System.out.println("Room Type" + roomtype);
  
    System.out.println("Room Area: " + setData(rooml, roomw));
  
  System.out.println("Number of aircon" + noOfacM);
  

  }

}


